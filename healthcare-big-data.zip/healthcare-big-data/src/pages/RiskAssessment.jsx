import React, { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { UploadCloud, FileText, AlertCircle, CheckCircle, Activity, Users, FileBarChart } from 'lucide-react';
import Papa from 'papaparse';
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, Legend, ResponsiveContainer } from 'recharts';
import './RiskAssessment.css';

const RiskAssessment = () => {
  const [data, setData] = useState(null);
  const [summary, setSummary] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState('');
  const fileInputRef = useRef(null);

  const calculateRisk = (row) => {
    let score = 0;
    const age = parseFloat(row.Age);
    const bmi = parseFloat(row.BMI);
    const sysBp = parseFloat(row.BloodPressure_Sys);
    const glucose = parseFloat(row.Glucose);
    const chol = parseFloat(row.Cholesterol);

    if (age > 60) score += 1;
    if (bmi > 30) score += 1;
    if (sysBp > 140) score += 1;
    if (glucose > 125) score += 1;
    if (chol > 240) score += 1;

    let level = 'Low';
    let color = '#10B981'; // Emerald 500
    if (score === 2) {
      level = 'Medium';
      color = '#F59E0B'; // Amber 500
    } else if (score >= 3) {
      level = 'High';
      color = '#EF4444'; // Red 500
    }

    return { ...row, RiskScore: score, RiskLevel: level, RiskColor: color };
  };

  const processData = (parsedData) => {
    // Filter out invalid rows
    const validData = parsedData.filter(item => item.PatientID && item.Age);
    if (validData.length === 0) {
      setError('No valid patient data found in the CSV.');
      setIsProcessing(false);
      return;
    }

    const analyzedData = validData.map(calculateRisk);
    
    // Calculate summary statistics
    const totalPatients = analyzedData.length;
    const avgAge = (analyzedData.reduce((acc, curr) => acc + parseFloat(curr.Age), 0) / totalPatients).toFixed(1);
    
    const riskCounts = { Low: 0, Medium: 0, High: 0 };
    analyzedData.forEach(patient => {
      riskCounts[patient.RiskLevel]++;
    });

    const riskDistribution = [
      { name: 'Low Risk', value: riskCounts.Low, color: '#10B981' },
      { name: 'Medium Risk', value: riskCounts.Medium, color: '#F59E0B' },
      { name: 'High Risk', value: riskCounts.High, color: '#EF4444' }
    ];

    setData(analyzedData);
    setSummary({
      total: totalPatients,
      avgAge,
      highRiskCount: riskCounts.High,
      riskDistribution
    });
    setIsProcessing(false);
  };

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    if (file.type !== 'text/csv' && !file.name.endsWith('.csv')) {
      setError('Please upload a valid CSV file.');
      return;
    }

    setError('');
    setIsProcessing(true);

    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: function(results) {
        processData(results.data);
      },
      error: function(error) {
        setError(`Error parsing CSV: ${error.message}`);
        setIsProcessing(false);
      }
    });
  };

  const triggerFileInput = () => {
    fileInputRef.current.click();
  };

  const resetData = () => {
    setData(null);
    setSummary(null);
    setError('');
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <div className="risk-assessment-container">
      <div className="risk-header px-side">
        <motion.h1 
          className="section-title text-gradient"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          Predictive Risk Analysis
        </motion.h1>
        <motion.p 
          className="section-subtitle"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          Upload patient health records to instantly process, visualize, and evaluate health risk categories using our heuristic algorithm.
        </motion.p>
      </div>

      <div className="px-side">
        {!data && (
          <motion.div 
            className="upload-zone"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
            onClick={triggerFileInput}
          >
            <input 
              type="file" 
              accept=".csv" 
              ref={fileInputRef} 
              onChange={handleFileUpload} 
              className="hidden-input" 
            />
            {isProcessing ? (
              <div className="processing-state">
                <Activity className="spinner-icon pulse" size={48} />
                <h3>Analyzing Data...</h3>
                <p>Running risk scoring models on the dataset.</p>
              </div>
            ) : (
              <div className="upload-prompt">
                <UploadCloud className="upload-icon bounce" size={64} />
                <h3>Drag & Drop or Click to Upload</h3>
                <p>Upload a Patient Data CSV file to begin analysis.</p>
                <span className="format-hint">Required columns include: PatientID, Age, BMI, BloodPressure_Sys, Glucose, Cholesterol</span>
              </div>
            )}
            
            {error && (
              <div className="error-message">
                <AlertCircle size={20} />
                <span>{error}</span>
              </div>
            )}
          </motion.div>
        )}

        {data && summary && (
          <motion.div 
            className="results-dashboard"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            <div className="dashboard-header flex justify-between items-center mb-8">
              <h2 className="text-2xl font-bold flex items-center gap-2"><CheckCircle className="text-emerald-500"/> Analysis Complete</h2>
              <button className="btn-secondary" onClick={resetData}>Upload New Dataset</button>
            </div>

            <div className="summary-cards">
              <div className="card glass-card">
                <div className="card-icon blue-gradient-bg"><Users size={24}/></div>
                <div className="card-content">
                  <p className="card-label">Total Patients</p>
                  <h3 className="card-value">{summary.total}</h3>
                </div>
              </div>
              <div className="card glass-card">
                <div className="card-icon purple-gradient-bg"><Activity size={24}/></div>
                <div className="card-content">
                  <p className="card-label">Average Age</p>
                  <h3 className="card-value">{summary.avgAge} <span>yrs</span></h3>
                </div>
              </div>
              <div className="card glass-card border-red">
                <div className="card-icon red-gradient-bg"><AlertCircle size={24}/></div>
                <div className="card-content">
                  <p className="card-label border-red-text">High Risk Count</p>
                  <h3 className="card-value border-red-text">{summary.highRiskCount}</h3>
                </div>
              </div>
            </div>

            <div className="charts-grid">
              <div className="chart-container glass-card">
                <h3 className="chart-title"><FileBarChart size={20}/> Risk Distribution</h3>
                <div className="chart-wrapper">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={summary.riskDistribution}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={80}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {summary.riskDistribution.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <RechartsTooltip contentStyle={{ backgroundColor: 'rgba(15, 23, 42, 0.9)', border: 'none', borderRadius: '8px', color: '#fff' }} />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </div>

              <div className="chart-container glass-card">
                <h3 className="chart-title"><Activity size={20}/> Risk Levels by Patient Count</h3>
                <div className="chart-wrapper">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={summary.riskDistribution}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
                      <XAxis dataKey="name" stroke="#94a3b8" />
                      <YAxis stroke="#94a3b8" />
                      <RechartsTooltip contentStyle={{ backgroundColor: 'rgba(15, 23, 42, 0.9)', border: 'none', borderRadius: '8px', color: '#fff' }} cursor={{fill: 'rgba(255, 255, 255, 0.05)'}} />
                      <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                        {summary.riskDistribution.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>

            <div className="data-table-section glass-card mt-8">
              <div className="table-header">
                <h3 className="chart-title flex items-center gap-2"><FileText size={20}/> Processed Patients Database</h3>
              </div>
              <div className="table-responsive">
                <table className="risk-table">
                  <thead>
                    <tr>
                      <th>Patient ID</th>
                      <th>Age</th>
                      <th>BMI</th>
                      <th>BP (Sys/Dia)</th>
                      <th>Glucose</th>
                      <th>Cholesterol</th>
                      <th>Risk Level</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.map((patient, index) => (
                      <tr key={index}>
                        <td><span className="font-mono text-sm">{patient.PatientID}</span></td>
                        <td>{patient.Age}</td>
                        <td>{patient.BMI}</td>
                        <td>{patient.BloodPressure_Sys}/{patient.BloodPressure_Dia}</td>
                        <td>{patient.Glucose}</td>
                        <td>{patient.Cholesterol}</td>
                        <td>
                          <span 
                            className="risk-badge" 
                            style={{ 
                              backgroundColor: `${patient.RiskColor}20`, 
                              color: patient.RiskColor,
                              border: `1px solid ${patient.RiskColor}40`
                            }}
                          >
                            {patient.RiskLevel}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default RiskAssessment;
