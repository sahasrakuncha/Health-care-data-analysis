import { motion } from 'framer-motion';
import { Server, Zap, Code, Cpu, PieChart, ArrowDown } from 'lucide-react';

const Methodology = () => {
  const techs = [
    { icon: Server, name: 'Hadoop', desc: 'Distributed storage platform (HDFS) allowing storage of massive unstructured health records across clusters.', color: '#f59e0b' },
    { icon: Zap, name: 'Apache Spark', desc: 'In-memory data processing engine used for lightning-fast real-time streams of patient IoT metrics.', color: '#ef4444' },
    { icon: Code, name: 'Python', desc: 'Primary scripting language for building robust data pipelines and statistical algorithms.', color: '#3b82f6' },
    { icon: Cpu, name: 'Machine Learning', desc: 'Scikit-learn/TensorFlow applied for predictive analytics and disease classification models.', color: '#8b5cf6' },
    { icon: PieChart, name: 'Data Visualization', desc: 'Creating interactive dashboards (via React & Recharts) to deliver actionable insights to doctors.', color: '#10b981' }
  ];

  const steps = [
    { title: 'Data Collection', desc: 'Injesting raw data from hospital EHRs, APIs, and CSV datasets into our data lake.' },
    { title: 'Data Cleaning', desc: 'Handling missing values, standardizing dates, and filtering out noisy sensor data.' },
    { title: 'Data Processing', desc: 'Using Spark to perform transformations, aggregations, and feature engineering at scale.' },
    { title: 'Analysis & ML', desc: 'Running clustering and classification models to detect patterns and predict health risks.' },
    { title: 'Visualization', desc: 'Querying processed data to render clean, readable charts for stakeholders.' }
  ];

  return (
    <div style={{ paddingBottom: '4rem' }}>
      <section style={{ padding: '4rem 0', background: 'var(--light-green)', textAlign: 'center' }}>
        <div className="container">
          <h1 style={{ fontSize: '3rem', fontWeight: '700', marginBottom: '1rem', color: 'var(--primary-green)' }}>
            Tech Stack & Methodology
          </h1>
          <p style={{ fontSize: '1.25rem', color: 'var(--text-muted)', maxWidth: '800px', margin: '0 auto' }}>
            The exact tools and pipeline we use to transform chaotic hospital logs into structured wisdom.
          </p>
        </div>
      </section>

      {/* Technologies Section */}
      <section className="section container">
        <h2 className="section-title">Technologies Used</h2>
        <div className="grid grid-cols-3" style={{ marginTop: '3rem' }}>
          {techs.map((t, idx) => (
            <motion.div 
              key={idx}
              className="card"
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              style={{ borderTop: `4px solid ${t.color}` }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1rem' }}>
                <t.icon size={32} color={t.color} />
                <h3 style={{ fontSize: '1.25rem', color: 'var(--dark-text)' }}>{t.name}</h3>
              </div>
              <p style={{ color: 'var(--text-muted)' }}>{t.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Pipeline Section */}
      <section style={{ background: 'var(--bg-color)', padding: '5rem 0' }}>
        <div className="container">
          <h2 className="section-title">Our Data Pipeline</h2>
          
          <div style={{ maxWidth: '800px', margin: '3rem auto 0 auto' }}>
            {steps.map((step, idx) => (
              <motion.div 
                key={idx}
                initial={{ opacity: 0, x: -50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.2 }}
                style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}
              >
                <div className="card" style={{ width: '100%', marginBottom: '0.5rem', borderLeft: '4px solid var(--primary-blue)' }}>
                  <h3 style={{ fontSize: '1.25rem', marginBottom: '0.5rem', color: 'var(--primary-blue)' }}>
                    {idx + 1}. {step.title}
                  </h3>
                  <p style={{ color: 'var(--text-muted)' }}>{step.desc}</p>
                </div>
                {idx < steps.length - 1 && (
                  <ArrowDown size={32} color="var(--border-color)" style={{ margin: '1rem 0' }} />
                )}
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Methodology;
