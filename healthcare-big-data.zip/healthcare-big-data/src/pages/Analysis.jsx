import { motion } from 'framer-motion';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  PieChart, Pie, Cell, LineChart, Line, AreaChart, Area
} from 'recharts';

const diseaseData = [
  { name: 'Cardio', cases: 4000 },
  { name: 'Diabetes', cases: 3000 },
  { name: 'Respiratory', cases: 2000 },
  { name: 'Oncology', cases: 2780 },
  { name: 'Neurology', cases: 1890 },
];

const ageData = [
  { ageGrp: '0-18', cardio: 20, respiratory: 800, diabetes: 50 },
  { ageGrp: '19-35', cardio: 150, respiratory: 600, diabetes: 300 },
  { ageGrp: '36-50', cardio: 800, respiratory: 400, diabetes: 800 },
  { ageGrp: '51-65', cardio: 1800, respiratory: 300, diabetes: 1200 },
  { ageGrp: '65+', cardio: 2400, respiratory: 500, diabetes: 1500 },
];

const recoveryData = [
  { month: 'Jan', rate: 65, avgDays: 12 },
  { month: 'Feb', rate: 68, avgDays: 11 },
  { month: 'Mar', rate: 75, avgDays: 9 },
  { month: 'Apr', rate: 82, avgDays: 8 },
  { month: 'May', rate: 80, avgDays: 8.5 },
  { month: 'Jun', rate: 85, avgDays: 7 },
];

const COLORS = ['#1e3a8a', '#3b82f6', '#10b981', '#f59e0b', '#8b5cf6'];

const Analysis = () => {
  return (
    <div style={{ paddingBottom: '4rem', background: '#f8fafc' }}>
      <section style={{ padding: '4rem 0', background: 'var(--primary-blue)', color: 'white', textAlign: 'center' }}>
        <div className="container">
          <h1 style={{ fontSize: '3rem', fontWeight: '700', marginBottom: '1rem' }}>
            Data Analysis & Insights
          </h1>
          <p style={{ fontSize: '1.25rem', color: 'var(--light-blue)', maxWidth: '800px', margin: '0 auto', opacity: 0.9 }}>
            Interactive dashboards highlighting key trends derived from processing 1M+ mock patient records.
          </p>
        </div>
      </section>

      <section className="section container">
        {/* Results & Insights Summary */}
        <div className="grid grid-cols-3" style={{ marginBottom: '4rem' }}>
          {[
            { metric: '1.2M', label: 'Records Processed', color: 'var(--primary-blue)' },
            { metric: '85%', label: 'Max Recovery Rate', color: 'var(--secondary-green)' },
            { metric: 'Cardio', label: 'Most Common Risk', color: '#ef4444' }
          ].map((stat, idx) => (
            <motion.div 
              key={idx}
              className="card"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              style={{ textAlign: 'center', borderBottom: `4px solid ${stat.color}` }}
            >
              <h3 style={{ fontSize: '3rem', fontWeight: '800', color: stat.color, marginBottom: '0.5rem' }}>{stat.metric}</h3>
              <p style={{ fontSize: '1.1rem', color: 'var(--text-muted)', fontWeight: '500' }}>{stat.label}</p>
            </motion.div>
          ))}
        </div>

        {/* Charts Grid */}
        <div className="grid grid-cols-2" style={{ gap: '2rem' }}>
          
          {/* Chart 1 */}
          <motion.div className="card" initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }}>
            <h3 style={{ marginBottom: '2rem', fontSize: '1.5rem', color: 'var(--dark-text)' }}>Disease Distribution</h3>
            <div style={{ height: '300px' }}>
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={diseaseData}
                    cx="50%"
                    cy="50%"
                    innerRadius={80}
                    outerRadius={110}
                    fill="#8884d8"
                    paddingAngle={5}
                    dataKey="cases"
                    label
                  >
                    {diseaseData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <p style={{ marginTop: '1rem', color: 'var(--text-muted)', fontSize: '0.9rem', textAlign: 'center' }}>
              Cardiovascular diseases form the largest portion of analyzed admissions.
            </p>
          </motion.div>

          {/* Chart 2 */}
          <motion.div className="card" initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }}>
            <h3 style={{ marginBottom: '2rem', fontSize: '1.5rem', color: 'var(--dark-text)' }}>Age vs Illness Trends</h3>
            <div style={{ height: '300px' }}>
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={ageData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="ageGrp" />
                  <YAxis />
                  <Tooltip wrapperStyle={{ borderRadius: '8px' }} />
                  <Legend />
                  <Bar dataKey="cardio" fill="var(--primary-blue)" name="Cardio" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="diabetes" fill="var(--primary-green)" name="Diabetes" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
            <p style={{ marginTop: '1rem', color: 'var(--text-muted)', fontSize: '0.9rem', textAlign: 'center' }}>
              Noticeable exponential risk increase in cardiovascular issues for patients aged 50+.
            </p>
          </motion.div>

          {/* Chart 3 */}
          <motion.div className="card" initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }} style={{ gridColumn: '1 / -1' }}>
            <h3 style={{ marginBottom: '2rem', fontSize: '1.5rem', color: 'var(--dark-text)' }}>Patient Recovery Rate (H1)</h3>
            <div style={{ height: '350px' }}>
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={recoveryData}>
                  <defs>
                    <linearGradient id="colorRate" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="var(--secondary-green)" stopOpacity={0.8}/>
                      <stop offset="95%" stopColor="var(--secondary-green)" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Area type="monotone" dataKey="rate" stroke="var(--primary-green)" fillOpacity={1} fill="url(#colorRate)" name="Recovery Rate %" />
                  <Line type="monotone" dataKey="avgDays" stroke="#ef4444" name="Avg Days in Hospital" strokeWidth={3} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
            <p style={{ marginTop: '1rem', color: 'var(--text-muted)', fontSize: '0.9rem', textAlign: 'center' }}>
              Recovery rates have improved significantly as average days spent in hospital decreased due to early ML-based interventions.
            </p>
          </motion.div>

        </div>
      </section>
    </div>
  );
};

export default Analysis;
