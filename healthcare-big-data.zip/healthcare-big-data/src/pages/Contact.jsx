import { motion } from 'framer-motion';
import { Mail, Linkedin, GraduationCap, ArrowRight, Bot, Wifi, Activity } from 'lucide-react';

const Contact = () => {
  return (
    <div style={{ paddingBottom: '4rem' }}>
      
      {/* Future Scope Section */}
      <section style={{ padding: '5rem 0', background: 'var(--light-blue)' }}>
        <div className="container">
          <div style={{ textAlign: 'center', marginBottom: '4rem' }}>
            <h2 className="section-title">Future Scope</h2>
            <p className="section-subtitle">The roadmap for scaling this project beyond academics.</p>
          </div>
          
          <div className="grid grid-cols-3">
            {[
              { icon: Bot, title: 'AI-Based Diagnosis', desc: 'Integrating deep learning models directly into the pipeline to auto-flag high risk patient scans in under 5 seconds.' },
              { icon: Wifi, title: 'IoT Healthcare Monitoring', desc: 'Live webhook integration with Apple Health and fitness trackers to stream real-time patient vitals directly to the dashboard.' },
              { icon: Activity, title: 'Personalized Medicine', desc: 'Genomic data processing via Spark to recommend bespoke drug treatments based on DNA markers.' }
            ].map((item, idx) => (
              <motion.div 
                key={idx}
                className="card"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                style={{ textAlign: 'center' }}
              >
                <div style={{ width: '64px', height: '64px', borderRadius: '50%', background: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 1.5rem auto', border: '1px solid var(--border-color)', boxShadow: 'var(--shadow-sm)' }}>
                  <item.icon size={32} color="var(--primary-blue)" />
                </div>
                <h3 style={{ fontSize: '1.25rem', marginBottom: '1rem', color: 'var(--dark-text)' }}>{item.title}</h3>
                <p style={{ color: 'var(--text-muted)' }}>{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Project Team / Contact Section */}
      <section className="section container">
        <div style={{ maxWidth: '800px', margin: '0 auto' }}>
          <motion.div 
            className="card"
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            style={{ background: 'linear-gradient(135deg, white, var(--light-green))', border: 'none', position: 'relative', overflow: 'hidden' }}
          >
            {/* Decorative background element */}
            <div style={{ position: 'absolute', right: '-10%', bottom: '-20%', opacity: 0.05 }}>
              <GraduationCap size={400} />
            </div>

            <div style={{ position: 'relative', zIndex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center' }}>
              <div style={{ background: 'var(--primary-green)', color: 'white', padding: '0.5rem 1rem', borderRadius: '2rem', fontSize: '0.875rem', fontWeight: '600', marginBottom: '2rem' }}>
                Project Author
              </div>
              
              <h2 style={{ fontSize: '2.5rem', fontWeight: '800', marginBottom: '0.5rem', color: 'var(--dark-text)' }}>
                Your Name
              </h2>
              <p style={{ fontSize: '1.25rem', color: 'var(--primary-blue)', fontWeight: '600', marginBottom: '0.5rem', display: 'flex', alignItems: 'center', gap: '0.5rem', justifyContent: 'center' }}>
                <GraduationCap size={24} /> BTech Computer Science & Engineering
              </p>
              <p style={{ fontSize: '1.1rem', color: 'var(--text-muted)', marginBottom: '3rem' }}>
                Your College / University Name
              </p>

              <div style={{ display: 'flex', gap: '2rem', justifyContent: 'center', flexWrap: 'wrap' }}>
                <a href="mailto:your.email@example.com" className="btn btn-outline" style={{ display: 'flex', gap: '0.5rem', alignItems: 'center', fontSize: '1.1rem', padding: '1rem 2rem' }}>
                  <Mail size={20} /> Email Me
                </a>
                <a href="https://linkedin.com/in/yourprofile" target="_blank" rel="noopener noreferrer" className="btn btn-primary" style={{ display: 'flex', gap: '0.5rem', alignItems: 'center', fontSize: '1.1rem', padding: '1rem 2rem' }}>
                  <Linkedin size={20} /> LinkedIn Profile <ArrowRight size={16} />
                </a>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
      
    </div>
  );
};

export default Contact;
