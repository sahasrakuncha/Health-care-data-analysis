import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowRight, Activity, Database, ShieldCheck } from 'lucide-react';

const Home = () => {
  return (
    <div>
      {/* Hero Section */}
      <section style={{ 
        minHeight: '80vh', 
        display: 'flex', 
        alignItems: 'center', 
        background: 'linear-gradient(to bottom, var(--light-blue), white)',
        position: 'relative',
        overflow: 'hidden'
      }}>
        {/* Background decorative elements */}
        <div style={{ position: 'absolute', top: '-10%', right: '-5%', width: '500px', height: '500px', borderRadius: '50%', background: 'rgba(59, 130, 246, 0.1)', filter: 'blur(60px)' }}></div>
        <div style={{ position: 'absolute', bottom: '-10%', left: '-5%', width: '400px', height: '400px', borderRadius: '50%', background: 'rgba(16, 185, 129, 0.1)', filter: 'blur(60px)' }}></div>

        <div className="container" style={{ position: 'relative', zIndex: 1 }}>
          <div style={{ maxWidth: '800px', margin: '0 auto', textAlign: 'center' }}>
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <div style={{ display: 'inline-block', padding: '0.5rem 1rem', background: 'var(--light-green)', color: 'var(--primary-green)', borderRadius: '2rem', fontWeight: '600', marginBottom: '1.5rem', fontSize: '0.875rem' }}>
                BTech CSE Final Year Project
              </div>
              <h1 style={{ fontSize: '3.5rem', fontWeight: '800', marginBottom: '1.5rem', color: 'var(--dark-text)' }}>
                Healthcare Data Analysis <br />
                <span className="text-gradient">Using Big Data</span>
              </h1>
              <p style={{ fontSize: '1.25rem', color: 'var(--text-muted)', marginBottom: '2.5rem', lineHeight: '1.8' }}>
                Leveraging the power of Hadoop, Spark, and Machine Learning to transform massive medical datasets into actionable insights for disease prediction, patient monitoring, and smarter hospital management.
              </p>
              
              <div style={{ display: 'flex', gap: '1rem', justifyContent: 'center' }}>
                <Link to="/analysis" className="btn btn-primary" style={{ padding: '1rem 2rem', fontSize: '1.125rem' }}>
                  Explore Dashboard <ArrowRight size={20} />
                </Link>
                <Link to="/about" className="btn btn-outline" style={{ padding: '1rem 2rem', fontSize: '1.125rem' }}>
                  Learn More
                </Link>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Quick Highlights Section */}
      <section className="section bg-white">
        <div className="container">
          <motion.div 
            className="grid grid-cols-3"
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, staggerChildren: 0.2 }}
          >
            {[
              { icon: Activity, title: 'Disease Prediction', desc: 'Identifying patterns & early warning signs.' },
              { icon: Database, title: 'Scalable Storage', desc: 'Managing millions of health records efficiently.' },
              { icon: ShieldCheck, title: 'Data Security', desc: 'Ensuring privacy and compliance in insights.' },
            ].map((item, idx) => (
              <motion.div key={idx} className="card" style={{ textAlign: 'center' }}>
                <div style={{ width: '60px', height: '60px', borderRadius: '50%', background: 'var(--light-blue)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 1.5rem auto' }}>
                  <item.icon size={30} color="var(--primary-blue)" />
                </div>
                <h3 style={{ fontSize: '1.25rem', marginBottom: '1rem' }}>{item.title}</h3>
                <p style={{ color: 'var(--text-muted)' }}>{item.desc}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default Home;
