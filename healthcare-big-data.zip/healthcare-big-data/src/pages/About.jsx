import { motion } from 'framer-motion';
import { Database, Stethoscope, Activity, FileText } from 'lucide-react';

const About = () => {
  return (
    <div style={{ paddingBottom: '4rem' }}>
      {/* Header */}
      <section style={{ padding: '4rem 0', background: 'var(--light-blue)', textAlign: 'center' }}>
        <div className="container">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            style={{ fontSize: '3rem', fontWeight: '700', marginBottom: '1rem', color: 'var(--primary-blue)' }}
          >
            About The Project
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            style={{ fontSize: '1.25rem', color: 'var(--text-muted)', maxWidth: '800px', margin: '0 auto' }}
          >
            Understanding the intersection of massive data systems and modern healthcare to save lives and optimize resources.
          </motion.p>
        </div>
      </section>

      {/* Importance Section */}
      <section className="section container">
        <div className="grid grid-cols-2" style={{ alignItems: 'center', gap: '4rem' }}>
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="section-title" style={{ textAlign: 'left' }}>The Importance of Healthcare Data</h2>
            <p style={{ color: 'var(--text-muted)', marginBottom: '1.5rem', fontSize: '1.1rem' }}>
              Every day, the healthcare industry generates enormous amounts of data—from electronic health records (EHRs) and medical imaging to wearable device metrics. 
            </p>
            <p style={{ color: 'var(--text-muted)', fontSize: '1.1rem' }}>
              When processed and analyzed correctly, this data holds the key to personalized medicine, early disease detection, and highly optimized hospital operations. Traditional databases fail to handle this scale, which is why Big Data technologies are vital.
            </p>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            style={{ background: 'var(--card-bg)', padding: '2rem', borderRadius: '1rem', boxShadow: 'var(--shadow-lg)', border: '1px solid var(--border-color)' }}
          >
            <h3 style={{ fontSize: '1.5rem', marginBottom: '1.5rem', color: 'var(--dark-text)', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <Stethoscope color="var(--primary-green)" /> Real-World Impact
            </h3>
            <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              {[
                { title: 'COVID-19 Tracking', desc: 'Real-time analysis of outbreak clusters and vaccination modeling.' },
                { title: 'Patient Records', desc: 'Unified view of a patient’s medical history across different providers.' },
                { title: 'AI Diagnosis', desc: 'Training ML models on millions of X-rays to detect anomalies faster.' }
              ].map((item, idx) => (
                <li key={idx} style={{ display: 'flex', gap: '1rem' }}>
                  <div style={{ marginTop: '0.25rem' }}><Activity size={20} color="var(--secondary-blue)" /></div>
                  <div>
                    <strong style={{ display: 'block', color: 'var(--dark-text)' }}>{item.title}</strong>
                    <span style={{ color: 'var(--text-muted)' }}>{item.desc}</span>
                  </div>
                </li>
              ))}
            </ul>
          </motion.div>
        </div>
      </section>

      {/* The 3 Vs Section */}
      <section style={{ background: 'var(--light-green)', padding: '5rem 0' }}>
        <div className="container">
          <h2 className="section-title">Defining Big Data in Healthcare</h2>
          <p className="section-subtitle">It's not just about the size; it's about the complexity. We characterize this data using the fundamental "3 Vs".</p>
          
          <div className="grid grid-cols-3">
            {[
              { title: 'Volume', desc: 'Terabytes to Petabytes of unstructured data generated from clinics, labs, and genomics research universally.', color: '#3b82f6' },
              { title: 'Velocity', desc: 'The incredible speed at which data streams in from real-time ICU monitors and IoT wearable health devices.', color: '#10b981' },
              { title: 'Variety', desc: 'Different shapes of data: Structured (tables), Semi-structured (JSON logs), and Unstructured (Doctor notes, MRIs).', color: '#8b5cf6' }
            ].map((v, idx) => (
              <motion.div 
                key={idx}
                className="card"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.2 }}
                style={{ textAlign: 'center' }}
              >
                <div style={{ width: '80px', height: '80px', borderRadius: '50%', background: `color-mix(in srgb, ${v.color} 15%, transparent)`, display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 1.5rem auto' }}>
                  <Database size={36} color={v.color} />
                </div>
                <h3 style={{ fontSize: '1.5rem', marginBottom: '1rem', color: v.color }}>{v.title}</h3>
                <p style={{ color: 'var(--text-muted)' }}>{v.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;
