import { Heart } from 'lucide-react';

const Footer = () => {
  return (
    <footer style={{ backgroundColor: 'var(--dark-text)', color: 'white', padding: '3rem 0', textAlign: 'center', marginTop: 'auto' }}>
      <div className="container">
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem', marginBottom: '1rem' }}>
          <Heart size={24} color="var(--secondary-green)" />
          <span style={{ fontSize: '1.5rem', fontWeight: '700' }}>HealthDataX</span>
        </div>
        <p style={{ color: '#94a3b8', marginBottom: '0.5rem' }}>
          BTech CSE Final Year Project
        </p>
        <p style={{ color: '#94a3b8', fontSize: '0.875rem' }}>
          &copy; {new Date().getFullYear()} Healthcare Data Analysis using Big Data. All rights reserved.
        </p>
      </div>
    </footer>
  );
};

export default Footer;
